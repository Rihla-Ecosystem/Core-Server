import { prisma } from '../config/prisma.js';
import { AppError } from '../middleware/errorHandler.js';
import { addXp } from './xp.service.js';

/**
 * Quest completion badges, keyed by journey slug.
 * Each quest awards its own badge when completed. New quests only need an
 * entry here (and a matching seeded badge) — no schema changes required.
 */
const JOURNEY_BADGE_BY_SLUG: Record<string, string> = {
  'scam-smart-traveler': 'Scam-Smart Traveler',
  'taxi-tricks': 'Taxi Savvy',
  'street-money-exchange': 'Money Maestro',
  'fake-guide-papyrus': 'Guide Guardian',
  'atm-card-scam': 'Card Safe',
  'giza-plateau': 'Pyramid Pioneer',
  'karnak-luxor': 'Temple Walker',
  'abu-simbel-nubia': 'Nubia Navigator',
  'coptic-islamic-cairo': 'Old Cairo Explorer',
};

type QuestTheme = 'scam' | 'archaeology';

/** Theme badges awarded when every quest in the theme is completed. */
const THEME_BADGE_BY_THEME: Record<QuestTheme, string> = {
  scam: 'Scam Shield',
  archaeology: 'Antiquity Explorer',
};

const THEME_BY_SLUG: Record<string, QuestTheme> = {
  'scam-smart-traveler': 'scam',
  'taxi-tricks': 'scam',
  'street-money-exchange': 'scam',
  'fake-guide-papyrus': 'scam',
  'atm-card-scam': 'scam',
  'giza-plateau': 'archaeology',
  'karnak-luxor': 'archaeology',
  'abu-simbel-nubia': 'archaeology',
  'coptic-islamic-cairo': 'archaeology',
};

const THEME_QUESTS: Record<QuestTheme, string[]> = {
  scam: [
    'scam-smart-traveler',
    'taxi-tricks',
    'street-money-exchange',
    'fake-guide-papyrus',
    'atm-card-scam',
  ],
  archaeology: [
    'giza-plateau',
    'karnak-luxor',
    'abu-simbel-nubia',
    'coptic-islamic-cairo',
  ],
};

interface JourneyStepView {
  id: string;
  stepNumber: number;
  title: string;
  content: string;
  xpReward: number;
}

interface JourneyView {
  id: string;
  slug: string;
  title: string;
  description: string | null;
  xpReward: number;
  isActive: boolean;
  steps: JourneyStepView[];
  completedSteps: number;
  totalSteps: number;
  isCompleted: boolean;
  startedAt: Date | null;
  completedAt: Date | null;
  nextStep: number | null;
}

function decorateJourney(journey: {
  id: string;
  slug: string;
  title: string;
  description: string | null;
  xpReward: number;
  isActive: boolean;
  steps: JourneyStepView[];
  progress: { startedAt: Date; completedAt: Date | null; steps: { stepId: string }[] }[];
}): JourneyView {
  const progress = journey.progress[0] ?? null;
  const completedStepIds = new Set((progress?.steps ?? []).map((s) => s.stepId));
  const totalSteps = journey.steps.length;
  const completedSteps = completedStepIds.size;
  const nextStep =
    completedSteps >= totalSteps
      ? null
      : journey.steps.find((s) => !completedStepIds.has(s.id))?.stepNumber ?? null;

  return {
    id: journey.id,
    slug: journey.slug,
    title: journey.title,
    description: journey.description,
    xpReward: journey.xpReward,
    isActive: journey.isActive,
    steps: journey.steps,
    completedSteps,
    totalSteps,
    isCompleted: progress?.completedAt != null,
    startedAt: progress?.startedAt ?? null,
    completedAt: progress?.completedAt ?? null,
    nextStep,
  };
}

async function awardBadgeByName(userId: string, name: string): Promise<boolean> {
  const badge = await prisma.badge.findUnique({ where: { name } });
  if (!badge) return false;
  const existing = await prisma.userBadge.findUnique({
    where: { userId_badgeId: { userId, badgeId: badge.id } },
  });
  if (existing) return false;
  await prisma.userBadge.create({ data: { userId, badgeId: badge.id } });
  return true;
}

export async function listJourneys(userId: string): Promise<JourneyView[]> {
  const journeys = await prisma.journey.findMany({
    where: { isActive: true },
    orderBy: { createdAt: 'asc' },
    include: {
      steps: {
        orderBy: { stepNumber: 'asc' },
        select: { id: true, stepNumber: true, title: true, content: true, xpReward: true },
      },
      progress: { where: { userId }, include: { steps: true } },
    },
  });
  return journeys.map((journey) => decorateJourney(journey));
}

export async function getJourneyDetail(userId: string, slug: string): Promise<JourneyView | null> {
  const journey = await prisma.journey.findUnique({
    where: { slug },
    include: {
      steps: {
        orderBy: { stepNumber: 'asc' },
        select: { id: true, stepNumber: true, title: true, content: true, xpReward: true },
      },
      progress: { where: { userId }, include: { steps: true } },
    },
  });
  if (!journey || !journey.isActive) return null;
  return decorateJourney(journey);
}

export async function startJourney(userId: string, slug: string): Promise<JourneyView | null> {
  const journey = await prisma.journey.findUnique({ where: { slug }, include: { steps: { orderBy: { stepNumber: 'asc' } } } });
  if (!journey || !journey.isActive) return null;

  const userJourney = await prisma.userJourney.upsert({
    where: { userId_journeyId: { userId, journeyId: journey.id } },
    update: {},
    create: { userId, journeyId: journey.id },
    include: { steps: true },
  });

  return decorateJourney({
    id: journey.id,
    slug: journey.slug,
    title: journey.title,
    description: journey.description,
    xpReward: journey.xpReward,
    isActive: journey.isActive,
    steps: journey.steps.map((s) => ({
      id: s.id,
      stepNumber: s.stepNumber,
      title: s.title,
      content: s.content,
      xpReward: s.xpReward,
    })),
    progress: [userJourney],
  });
}

export interface CompleteJourneyStepResult {
  journey: string;
  step: number;
  completed: number;
  total: number;
  journeyCompleted: boolean;
  xpAwarded: number;
  badgesAwarded: string[];
}

export async function completeJourneyStep(
  userId: string,
  slug: string,
  stepNumber: number,
): Promise<CompleteJourneyStepResult | null> {
  const journey = await prisma.journey.findUnique({
    where: { slug },
    include: { steps: { orderBy: { stepNumber: 'asc' } } },
  });
  if (!journey || !journey.isActive) return null;

  const step = journey.steps.find((s) => s.stepNumber === stepNumber);
  if (!step) return null;

  // Sequential gating: a step can only be completed after the previous one.
  if (stepNumber > 1) {
    const progress = await prisma.userJourney.findUnique({
      where: { userId_journeyId: { userId, journeyId: journey.id } },
      include: { steps: true },
    });
    if (!progress) {
      throw new AppError(409, 'Start the journey before completing steps');
    }
    const previousStep = journey.steps.find((s) => s.stepNumber === stepNumber - 1);
    if (previousStep && !progress.steps.some((cs) => cs.stepId === previousStep.id)) {
      throw new AppError(400, 'Complete the previous step first');
    }
  }

  const { progress, wasNewlyCompleted } = await prisma.$transaction(async (tx) => {
    const progress = await tx.userJourney.upsert({
      where: { userId_journeyId: { userId, journeyId: journey.id } },
      update: {},
      create: { userId, journeyId: journey.id },
    });
    const existingCompletion = await tx.userJourneyStep.findUnique({
      where: { userJourneyId_stepId: { userJourneyId: progress.id, stepId: step.id } },
    });
    if (existingCompletion) return { progress, wasNewlyCompleted: false };
    await tx.userJourneyStep.create({ data: { userJourneyId: progress.id, stepId: step.id } });
    return { progress, wasNewlyCompleted: true };
  });

  let xpAwarded = 0;
  const badgesAwarded: string[] = [];

  if (wasNewlyCompleted) {
    const awardKey = `journey_step:${journey.id}:${step.id}`;
    const existing = await prisma.xpTransaction.findFirst({ where: { userId, reason: awardKey } });
    if (!existing) {
      await addXp(userId, step.xpReward, awardKey);
      xpAwarded += step.xpReward;
    }
  }

  const total = journey.steps.length;
  const completed = await prisma.userJourneyStep.count({ where: { userJourneyId: progress.id } });
  const journeyCompleted = completed >= total;

  if (journeyCompleted) {
    await prisma.userJourney.update({
      where: { id: progress.id },
      data: { completedAt: new Date() },
    });

    const existing = await prisma.xpTransaction.findFirst({
      where: { userId, reason: `journey_complete:${journey.id}` },
    });
    if (!existing) {
      await addXp(userId, journey.xpReward, `journey_complete:${journey.id}`);
      xpAwarded += journey.xpReward;
    }

    const questBadge = JOURNEY_BADGE_BY_SLUG[journey.slug];
    if (questBadge && (await awardBadgeByName(userId, questBadge))) {
      badgesAwarded.push(questBadge);
    }

    const theme = THEME_BY_SLUG[journey.slug];
    if (theme) {
      const quests = THEME_QUESTS[theme];
      const completedQuests = await prisma.userJourney.count({
        where: {
          userId,
          journey: { slug: { in: quests } },
          completedAt: { not: null },
        },
      });
      if (completedQuests >= quests.length) {
        const themeBadge = THEME_BADGE_BY_THEME[theme];
        if (await awardBadgeByName(userId, themeBadge)) {
          badgesAwarded.push(themeBadge);
        }
      }
    }
  }

  return {
    journey: slug,
    step: stepNumber,
    completed,
    total,
    journeyCompleted,
    xpAwarded,
    badgesAwarded,
  };
}
